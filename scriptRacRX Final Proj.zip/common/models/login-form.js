'use strict';

module.exports = function(Loginform) {

};
